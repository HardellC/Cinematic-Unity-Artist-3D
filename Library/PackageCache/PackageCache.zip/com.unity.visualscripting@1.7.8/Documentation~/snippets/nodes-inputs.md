---
title: nodes-inputs
---

node has the following input ports: