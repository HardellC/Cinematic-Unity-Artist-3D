---
title: nodes-input-output-trigger
---

<tr>
<td><strong>Trigger</strong></td>
<td>Output Trigger</td>
<td>The control output port. Make a connection to specify what Visual Scripting should do after the configured Input event occurs in your application.</td>
</tr>