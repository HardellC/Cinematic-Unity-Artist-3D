namespace Unity.VisualScripting
{
    public sealed class SharedEditorTextureDictionary
    {
        public SharedEditorTextureDictionary()
        {
        }
    }
}
