namespace Unity.VisualScripting
{
    public abstract class GraphElementDescription : Description, IGraphElementDescription
    {
    }
}
